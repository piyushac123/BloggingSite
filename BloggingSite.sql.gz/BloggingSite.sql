-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 07, 2019 at 07:54 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `BloggingSite`
--
CREATE DATABASE IF NOT EXISTS `BloggingSite` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `BloggingSite`;

-- --------------------------------------------------------

--
-- Table structure for table `Comment`
--

DROP TABLE IF EXISTS `Comment`;
CREATE TABLE `Comment` (
  `pid` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  `message` varchar(100) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Feedback`
--

DROP TABLE IF EXISTS `Feedback`;
CREATE TABLE `Feedback` (
  `fid` int(10) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `response` int(1) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Feedback`
--

INSERT INTO `Feedback` (`fid`, `name`, `country`, `response`, `comment`) VALUES
(1, 'PiyushChincholikar', 'India', 1, 'Good to see a new blogging site'),
(2, 'PiyushChincholikar', 'India', 1, 'This is my next feedback');

-- --------------------------------------------------------

--
-- Table structure for table `Likes`
--

DROP TABLE IF EXISTS `Likes`;
CREATE TABLE `Likes` (
  `uid` int(10) DEFAULT NULL,
  `pid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Post`
--

DROP TABLE IF EXISTS `Post`;
CREATE TABLE `Post` (
  `pid` int(10) NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Post`
--

INSERT INTO `Post` (`pid`, `uid`, `pname`, `category`, `date_time`) VALUES
(4, 1, 'Nerd Fitness', 'Health and Fitness', '2019-04-03 13:45:22'),
(5, 1, 'Blogilates', 'Health and Fitness', '2019-04-03 13:46:44'),
(7, 1, 'First Flowers', 'Nature Blog', '2019-04-03 13:50:25'),
(8, 3, 'Spring Rolls In', 'Nature Blog', '2019-04-03 13:51:37'),
(9, 3, 'Back in Thick Air', 'Nature Blog', '2019-04-03 13:52:14'),
(10, 3, 'Atlantic-Pacific', 'Fashion Blog', '2019-04-03 13:54:59'),
(11, 3, 'The Daileigh', 'Fashion Blog', '2019-04-03 13:55:39');

-- --------------------------------------------------------

--
-- Table structure for table `Registration`
--

DROP TABLE IF EXISTS `Registration`;
CREATE TABLE `Registration` (
  `uid` int(10) NOT NULL,
  `fullName` varchar(25) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `channelName` varchar(20) DEFAULT NULL,
  `flag` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Registration`
--

INSERT INTO `Registration` (`uid`, `fullName`, `email`, `password`, `channelName`, `flag`) VALUES
(1, 'PiyushChincholikar', 'piyush@gmail.com', 'pac', 'Checkmate', 0),
(3, 'ParmitaChincholikar', 'parmita@gmail.com', 'parmita', 'New Girls Channel', 0),
(4, 'bharatGupta', 'guptabharat297@gmail', '12', 'wqf', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Subscription`
--

DROP TABLE IF EXISTS `Subscription`;
CREATE TABLE `Subscription` (
  `uidrequest` int(10) DEFAULT NULL,
  `uidresponse` int(10) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Comment`
--
ALTER TABLE `Comment`
  ADD KEY `PostID` (`pid`),
  ADD KEY `UserID1` (`uid`);

--
-- Indexes for table `Feedback`
--
ALTER TABLE `Feedback`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `Likes`
--
ALTER TABLE `Likes`
  ADD KEY `PostID2` (`pid`),
  ADD KEY `UserID2` (`uid`);

--
-- Indexes for table `Post`
--
ALTER TABLE `Post`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `UserID` (`uid`);

--
-- Indexes for table `Registration`
--
ALTER TABLE `Registration`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `Subscription`
--
ALTER TABLE `Subscription`
  ADD KEY `UserID3` (`uidrequest`),
  ADD KEY `UserID4` (`uidresponse`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Feedback`
--
ALTER TABLE `Feedback`
  MODIFY `fid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Post`
--
ALTER TABLE `Post`
  MODIFY `pid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `Registration`
--
ALTER TABLE `Registration`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Comment`
--
ALTER TABLE `Comment`
  ADD CONSTRAINT `PostID` FOREIGN KEY (`pid`) REFERENCES `Post` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `UserID1` FOREIGN KEY (`uid`) REFERENCES `Registration` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Likes`
--
ALTER TABLE `Likes`
  ADD CONSTRAINT `PostID2` FOREIGN KEY (`pid`) REFERENCES `Post` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `UserID2` FOREIGN KEY (`uid`) REFERENCES `Registration` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Post`
--
ALTER TABLE `Post`
  ADD CONSTRAINT `UserID` FOREIGN KEY (`uid`) REFERENCES `Registration` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Subscription`
--
ALTER TABLE `Subscription`
  ADD CONSTRAINT `UserID3` FOREIGN KEY (`uidrequest`) REFERENCES `Registration` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `UserID4` FOREIGN KEY (`uidresponse`) REFERENCES `Registration` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
